<?php

require_once 'autoload.php';
use OSS\OssClient;
use OSS\Core\OssException;

$client = new OssClient('U6GLwyx2g6jrOL1V', 'W05IEVd3nio2BVCG5GoMG6QekiO1di', 'http://oss-cn-qingdao.aliyuncs.com');


